const sudokuGrid = document.getElementById('sudoku-grid');
const checkErrorsButton = document.getElementById('checkErrors');
const hintButton = document.getElementById('hint');
const difficultySelect = document.getElementById('difficulty');
const resetButton = document.getElementById('reset');

const initialBoard = {
    easy: [
        [5, 3, '', '', 7, '', '', '', ''],
        [6, '', '', 1, 9, 5, '', '', ''],
        ['', 9, 8, '', '', '', '', 6, ''],
        [8, '', '', '', 6, '', '', '', 3],
        [4, '', '', 8, '', 3, '', '', 1],
        [7, '', '', '', 2, '', '', '', 6],
        ['', 6, '', '', '', '', 2, 8, ''],
        ['', '', '', 4, 1, 9, '', '', 5],
        ['', '', '', '', 8, '', '', 7, 9]
    ],
    medium: [
    ],
    hard: [
    ]
};

let board = JSON.parse(JSON.stringify(initialBoard.easy));

function renderBoard() {
    sudokuGrid.innerHTML = '';
    board.forEach((row, rowIndex) => {
        row.forEach((cell, cellIndex) => {
            const input = document.createElement('input');
            input.type = 'text';
            input.maxLength = 1;
            if (cell !== '') {
                input.value = cell;
                input.disabled = true;
            }
            input.dataset.row = rowIndex;
            input.dataset.cell = cellIndex;
            sudokuGrid.appendChild(input);
        });
    });
}

function checkErrors() {
    const inputs = sudokuGrid.querySelectorAll('input');
    inputs.forEach(input => {
        input.classList.remove('error');
        const value = input.value;
        if (value && !isValidPlacement(parseInt(value), parseInt(input.dataset.row), parseInt(input.dataset.cell))) {
            input.classList.add('error');
        }
    });
}

function isValidPlacement(num, row, col) {
    for (let i = 0; i < 9; i++) {
        if (board[row][i] == num && i !== col) return false;
        if (board[i][col] == num && i !== row) return false;
        const boxRow = 3 * Math.floor(row / 3) + Math.floor(i / 3);
        const boxCol = 3 * Math.floor(col / 3) + (i % 3);
        if (board[boxRow][boxCol] == num && (boxRow !== row || boxCol !== col)) return false;
    }
    return true;
}

function giveHint() {
    let emptyCells = [];
    sudokuGrid.querySelectorAll('input').forEach(input => {
        if (!input.value && !input.disabled) emptyCells.push(input);
    });
    if (emptyCells.length > 0) {
        const randomCell = emptyCells[Math.floor(Math.random() * emptyCells.length)];
        const row = randomCell.dataset.row;
        const col = randomCell.dataset.cell;
        randomCell.value = initialBoard[difficultySelect.value][row][col];
        randomCell.classList.add('hint');
    }
}

function resetBoard() {
    board = JSON.parse(JSON.stringify(initialBoard[difficultySelect.value]));
    renderBoard();
}


checkErrorsButton.addEventListener('click', checkErrors);
hintButton.addEventListener('click', giveHint);
difficultySelect.addEventListener('change', resetBoard);
resetButton.addEventListener('click', resetBoard);

renderBoard();
